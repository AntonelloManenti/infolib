# infolib for python
A simple, robust and slim library proposal for Pandas Dataframe.
 
Tired of .info .describe .shape .columns .dtype?
 
All-in-one pip install infolib import infolib infolib (PandasDataframe)

Work in progess.
